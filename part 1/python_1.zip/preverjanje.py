razred = [1, 2, 3]
oddelki = ['a', 'b', 'c', 'd']

print(str(razred[1]) + '.' + oddelki[1])