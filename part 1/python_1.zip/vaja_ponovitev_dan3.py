import requests

kraj = str(input("Vnesi kraj tvojega sončnega zahoda (kolk kjut): "))
url_kraj = ('http://maps.googleapis.com/maps/api/geocode/json?address=%s' %(kraj))
print(url_kraj)
podatki = requests.get(url_kraj)
podatki_decoded = podatki.json()

prvi_lat = podatki_decoded['results'][0]['geometry']['location']['lat']
prvi_long = podatki_decoded['results'][0]['geometry']['location']['lng']
print(prvi_lat)
print(prvi_long)

url_zahod = ('https://api.sunrise-sunset.org/json?lat=%s&lng=%s' %(prvi_lat, prvi_long))
print(url_zahod)
podatki_zahod = requests.get(url_zahod)
podatki_zahod_decoded = podatki_zahod.json()

vzhod = podatki_zahod_decoded['results']['sunrise']
zahod = podatki_zahod_decoded['results']['sunset']
print("V", kraj, "bo sonce vzšlo ob", vzhod, "in zašlo ob", zahod)
