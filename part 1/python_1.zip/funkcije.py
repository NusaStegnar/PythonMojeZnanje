# Fibonacci
def fib(n):
    """Print a Fibonacci series up to n."""
    a, b = 0, 1
    while a < n:
        print(a, end=' ')
        a, b = b, a+b
    print()

fib(50)

# Primer imena
def say_hello(ime = "neznanec"):
    print("Živjo %s!" % ime) #isto je print("Živjo" + ime + "!")

say_hello("Klara")
say_hello("Aljaž")
say_hello()

def say_hello(ime = "neznanec"):
    return "Živjo %s!" % ime

print(say_hello("Dino"))
klara = say_hello("Klara")
print(klara)

# Primer 3
string = str(input("Dej neki napiš: "))
char = str(input("Dodaj še klicaj: "))

def blabla():
    print(string + char)

if char == "!":
    print("Pohvalno")
    blabla()
else:
    print("Ne veš kaj je klicaj... sramota")

# povprečne vrednosti

a = [1, 2, 3, 4]
b = [5, 6, 7, 8, 9]
c = [10, 11, 12, 13, 14]

def povprecje(seznam):
    return sum(seznam) / len(seznam)

print (povprecje(a))
print (povprecje(b))
print (povprecje(c))

