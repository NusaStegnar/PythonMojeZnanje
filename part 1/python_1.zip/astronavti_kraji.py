import requests

#http://api.open-notify.org/astros.json

astronavti = requests.get('http://api.open-notify.org/astros.json')
#astronavti_vsebina = astronavti.content
astronavti_decoded = astronavti.json()
print(astronavti_decoded)

stevilo_astr = astronavti_decoded['number'] #v katerem slovarju, kateri ključ
print("Trenutno so v vesolju:", stevilo_astr, "astronavtov")
print("Imena astronavtov:")
for astronavt in astronavti_decoded['people']:
    print(astronavt['name'])


# Kraji
kraj1 = str(input("Vnesi prvi kraj: "))
kraj2 = str(input("Vnesi drugi kraj: "))

x = kraj1
y = kraj2 

url = ('http://maps.googleapis.com/maps/api/distancematrix/json?origins=%s&destinations=%s' %(x,y))
print(url)
razdalja = requests.get(url)
razdalja_decoded = razdalja.json()
print(razdalja_decoded)

#kilometri = razdalja_decoded['rows']['elements'][0]['distance']['text']
kilometri = razdalja_decoded['rows'][0]['elements'][0]['distance']['text'] 
#print(kilometri)

print("Med krajem", kraj1, "in krajem", kraj2, "je", kilometri)