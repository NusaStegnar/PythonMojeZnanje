# uporabniški input: uporabimo funkcijo input() in shranimo v spremenljivko
ime = input("Kako ti je ime?")
print(f"Pozdravljen, {ime}!")
print("Pozdravljen " + ime)

# if zanka
ime = input("Kako ti je ime?")
spol = input("Katerega spola si (M/Ž)?")

if spol == "M":
    print(f"Pozdravljen, {ime}!")
elif spol == "Ž":
    print(f"Pozdravljena, {ime}!")
else:
    print(f"{ime}, spola '{spol}' žal ne podpiramo!")

# pass
ime = input("Kako ti je ime?")

if len(ime) < 3:
    pass
    # npr. da se spomnimo, da moramo to implementirati

print("Konec programa")

# -------------------------------------------------------------------------
# while zanka

print (1)
print (2)
print (3)
#...
print (99)
print (100)

stevilo = 1
while stevilo < 101 :
   print(stevilo)
   stevilo += 1

# for loop
items = [1, 2, 3, 4, 5]

for item in items:
    print(item)

print("---------")
for i in range(5):
    print(i + 1)
    
print("---------")
items = ['banana', 'japka', 'ananas']
for item in items:
    print(item)

for n in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] :
   print ("2 na", str(n), "je", str(2**n))

# Continue
items = ['banana', 'japka', 'ananas']
for item in items:
    if item == 'japka':
        continue
    print(item)

# break
items = ['banana', 'japka', 'ananas']
for item in items:
    if item == 'japka':
        break
    print(item)

