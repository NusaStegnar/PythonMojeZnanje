import random

st = random.randint(1, 100)
# to zgoraj jim podaš, ostalo je samostojno delo

while True:
    ugib = int(input("Vnesi število:"))
    if ugib > st:
        print("Število, ki ga iščeš, je manjše!")
    elif ugib < st:
        print("Število, ki ga iščeš, je večje!")
    else:
        print("Bravoooo, uganil si!")
        break


# Verzija 2
    
ponovitve = 0
print('Živjo, kako ti je ime')
ime = input()
stevilo = random.randint(1, 20)

print('Poskusi!')

while ponovitve < 6:    
    poskus = input()
    poskus = int(poskus)
    ponovitve = ponovitve + 1

    if poskus < stevilo:
        print('Premalo')

    if poskus > stevilo:
        print('Prevec')

    if poskus == stevilo:
        break

if poskus == stevilo:
    ponovitve = str(ponovitve)
    print('Bravo, ' + ime + '! Uganil si v ' + ponovitve + ' poskusih!')

if poskus != stevilo:
    stevilo = str(stevilo)
    print('Žal... Število, na katerega sem mislil je bilo ' + number)