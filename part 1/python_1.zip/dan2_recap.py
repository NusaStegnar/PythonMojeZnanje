#Vaja 1
import math as m
print(m.sqrt(45))
print(m.sqrt(225))
print(m.sqrt(51023))
print(m.sqrt(442))

#Vaja 2
uporabnik = input("Vnesi svoje ime in priimek: ")
starost = input("Vnesi svojo starost:")
print("Pozdravljen " + uporabnik + ", ki je star " + starost + " let")

#Vaja 3
starost = int(input("Vnesi svojo starost:"))
print(starost > 18)

#Vaja 4
stevilo1 = int(input("Vnesi stevilo 1:" ))
stevilo2 = int(input("Vnesi 3stevilo 2:"))
print(stevilo1 + stevilo2)

